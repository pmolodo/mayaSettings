Author: Paul Molodowitch
Email: PMP.calin79@neverbox.com
PMP_reloadTextures
Version: 0.5

============================================================

TO INSTALL: Unzip the PMP_reloadTextures.zip to your maya settings directory -
   on windows, this usually looks like:

        C:\Documents and Settings\YOUR_USERNAME_HERE\maya\MAYA_VERSION_HERE

   (Note - I haven't tested this on platforms other than windows! Use at your own risk!)
   After unzipping, the following files should be located as follows:

         C:\Documents and Settings\YOUR_USERNAME_HERE\maya\MAYA_VERSION_HERE\scripts\PMP_reloadTextures.mel
         C:\Documents and Settings\YOUR_USERNAME_HERE\maya\MAYA_VERSION_HERE\scripts\PMP_reloadTexturesPython.zip
         C:\Documents and Settings\YOUR_USERNAME_HERE\maya\MAYA_VERSION_HERE\prefs\icons\PMP_reloadTextures.bmp
         C:\Documents and Settings\YOUR_USERNAME_HERE\maya\MAYA_VERSION_HERE\prefs\shelves\shelf_PMP_reloadTextures.mel

   If your unzipping program did not preserve the directory structure when
   unzipping, move the files to the indicated places yourself.

   Note for those who want to install in a location other than the default:
      PMP_reloadTextures.mel and PMP_reloadTexturesPython.zip can be placed in
      any mel script directory - ie, any directory in MAYA_SCRIPT_PATH - AS
      LONG AS BOTH the .zip and .mel are in the SAME directory

============================================================

TO USE: The installation will create a new shelf, PMP_reloadTextures, with a
   single button.  (You'll likely want to middle-mouse drag this button to
   another shelf of your choice, and then delete this shelf.)

   If you single click the button, it will reload the textures associated with
   any selected objects.

   If you double click the button, it will reload ALL the file textures in the
   scene.

   In addition, when attempting to reload textures, both will do some
   'housekeeping':

      If it encounters any file nodes that reference nonexistent files, it will
      try to find them in the sourceimages folder (or a subfolder), and correct
      the reference if it does.

      It will also attempt to correct paths that have been made to point to
      'data' to point back to 'sourceimages', if it can find a matching file in
      sourceimages.  This is done because maya (or perhaps just mental ray) has
      a rather annoying habit of copying textures to the data directory, and
      then changing the file reference for the node to the new
      location... leaving you wondering why the texture isn't updating even
      though you've reloaded it.

   If you're a MEL-ish type, the commands you want are PMP_reloadTextures() and
      PMP_reloadAllTextures()

============================================================

Version History:
        0.5 - Initial version. Has a fancy-dancy loading-progress bar!
              Worship the GUI! (2008-02
